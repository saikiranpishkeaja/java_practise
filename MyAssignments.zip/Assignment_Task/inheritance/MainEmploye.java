package inheritance;

public class MainEmploye {

	public static void main(String[] args) {
		Employe emp= new Employe("Saikiran ARJUN","KT201");
		

	} 

}
