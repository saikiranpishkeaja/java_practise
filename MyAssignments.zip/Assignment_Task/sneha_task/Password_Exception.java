package sneha_task;

public class Password_Exception {

	public static void main(String[] args) {
		

	}

}
