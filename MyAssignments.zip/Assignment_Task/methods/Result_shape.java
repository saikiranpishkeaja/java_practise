package methods;

interface Shape {
	void calculateArea();
	void draw();
}

class Circle implements Shape {
	double radius=1;
	public void calculateArea() {
		 System.out.println("Area of circle :"+)
	 }
}
public class Result_shape {

	public static void main(String[] args) {
		
	}

}
